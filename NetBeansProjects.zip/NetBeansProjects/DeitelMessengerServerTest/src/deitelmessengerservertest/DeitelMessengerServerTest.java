/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deitelmessengerservertest;

// Fig. 24.19: DeitelMessengerServerTest.java
// Test the DeitelMessengerServer class.


public class DeitelMessengerServerTest 
{   
   public static void main ( String args[] ) 
   {
      DeitelMessengerServer application = new DeitelMessengerServer();
      application.startServer(); // start server
   } // end main
} // end class DeitelMessengerServerTest


