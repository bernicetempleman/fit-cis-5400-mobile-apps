/*
Fig 28.2: ReadServerFileTest.java
Create and stat a ReadServerFile

 */
package ch28.example1;

import javax.swing.JFrame;

public class ReadServerFileTest 
{


    public static void main(String[] args) {
        ReadServerFile application = new ReadServerFile();
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
